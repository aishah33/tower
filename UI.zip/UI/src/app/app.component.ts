import { Component } from '@angular/core';
import { SwUpdate } from '@angular/service-worker';
import { routerTransition } from './shared/animations';
import { NavigationService } from './shared/navigation.service';
import { from } from 'rxjs';
import { Router, NavigationEnd, Event } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    routerTransition()
  //   trigger('fadeAnimation', [
  //     transition('* <=> *', [
  //       group([
  //         query(':enter',[
  //           style({transform: 'translateX(100%)'}),
  //           animate('0.4s ease-in-out', style({transform: 'translateX(0%)'}))
  //         ], {optional: true}),
  //         query(':leave',[
  //           style({transform: 'translateX(0%)'}),
  //           animate('0.4s ease-in-out', style({transform: 'translateX(-100%)'}))
  //         ], {optional: true})
  //       ])
    
  //   ])
  // ])
  ]
})
export class AppComponent {
  update:boolean = false
  constructor(
    private navigationService: NavigationService ,updates:SwUpdate, private router:Router
  ) {
    updates.available.subscribe(event=>{
      this.update = true;
    });

  //   router.events.subscribe( (event: Event) => {

  //     if (event instanceof NavigationEnd) {
  //        console.log("change route");
  //       let scrollToTop = window.setInterval(() => {
  //         let pos = window.pageYOffset;
  //         if (pos > 0) {
  //           window.scrollTo(0, pos - 20); // how far to scroll on each step
  //         } else {
  //           window.clearInterval(scrollToTop);
  //         }
  //       }, 16);
  //     }

  // });
  }
  
  getDepth(outlet) {
    return outlet.activatedRouteData['depth'];

  }

  getRouteAnimation(outlet) {
    return this.navigationService.animationValue;
  }
 }

 
