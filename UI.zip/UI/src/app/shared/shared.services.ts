import { Injectable } from "@angular/core";
import { MatSidenav } from "@angular/material";

@Injectable()
export class SharedService {
  public header:any={};
  public footer:any={};
  public sideNav:MatSidenav;
}
