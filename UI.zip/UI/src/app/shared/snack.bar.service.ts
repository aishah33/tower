import { Injectable } from "@angular/core";
import { MatSnackBar } from "@angular/material";


@Injectable()
export class SnackBarService {
    constructor(private snackBar: MatSnackBar) {
    }
    public show(msg: string, actionText?: string) {
        actionText = actionText ? actionText : "DISMISS";
        return this.snackBar.open(msg, actionText, {
            duration: 3000
        }).onAction();
    }
}