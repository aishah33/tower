import { Component, Inject, AfterViewInit } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import Swiper from 'swiper';

export interface DialogData {
  title: string;
  content: string;
  showTextBox:boolean;
  no:string;
  yes:string;
}

@Component({
  selector: 'popup-img',
  templateUrl: 'popup-img.html',
})
export class PopupImg implements AfterViewInit {
 
  constructor(
    public dialogRef: MatDialogRef<PopupImg>,
    @Inject(MAT_DIALOG_DATA) private data: DialogData) {
   
   
  }
  
  ngAfterViewInit() {
    var swiper = new Swiper('.swiper-container', {
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
  }
}