import { Component, Inject } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

export interface DialogData {
  title: string;
  content: string;
  showTextBox:boolean;
  no:string;
  yes:string;
}

@Component({
  selector: 'confirmation-dialog',
  templateUrl: 'confirmation-dialog.html',
})
export class ConfirmationDialog {
 
  txtValue:String;
  resultDefault = { title: "Delete Confirmation", content: "Delete selected item will not be recoverd.",yes:"Ok",no:"Cancel",showTextBox:false };
  result= this.resultDefault;
  constructor(
    public dialogRef: MatDialogRef<ConfirmationDialog>,
    @Inject(MAT_DIALOG_DATA) private data: DialogData) {
   
      if (data != null) {
        this.result = data;
      }
    
  }
}