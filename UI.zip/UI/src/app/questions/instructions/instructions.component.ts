import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-instructions',
    templateUrl: './instructions.component.html'
})
export class InstructionsComponent implements OnInit {
  

    constructor(public headerService: HeaderService, private router: Router) {
        headerService.header = { title: 'Instructions', headerIcon: { icon: "chevron_left" } }

    }

    GoToQuestionPage(){
        this.router.navigate(['/questions/block-number']);
    }

    ngOnInit() { }

}