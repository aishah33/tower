import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-q-17',
    templateUrl: './q-17.component.html'
})
export class Q17Component implements OnInit {

  AnswerOptions: any = [];
  Scores: any = [];

    constructor(public headerService: HeaderService, private router: Router) {
        headerService.header = { title: 'Block No. 17', headerIcon: { icon: "chevron_left", } }

        this.LoadAnswerOptions();
    }

    LoadAnswerOptions(){
      
      this.AnswerOptions.push({
        Option: "A",
        Desc: "brushes",
        Class: "abc"
      },
      {
        Option: "B",
        Desc: "brush",
        Class: "abc"
      },
      {
        Option: "C",
        Desc: "brushed",
        Class: "abc"
      });

      this.Scores = JSON.parse(sessionStorage.getItem('Scores'));

      let Question: any = {};
      let Option: any = {};

      Question = this.Scores.filter(i => i.Question === 17)[0];

      if(Question.IsCorrect !== null){
        Option = this.AnswerOptions.filter(i => i.Option === Question.ScannedAnswer)[0];
        Option.Class = Question.IsCorrect === true ? "correct abc" : "wrong abc";
      }

    }

    GoToQRScannerPage(){
      sessionStorage.setItem("QuestionNo", "17");
      this.router.navigate(['/questions/qr-scanner'])
    }

    ngOnInit() {
    }
}