import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-q-19',
    templateUrl: './q-19.component.html'
})
export class Q19Component implements OnInit {

  AnswerOptions: any = [];
  Scores: any = [];

    constructor(public headerService: HeaderService, private router: Router) {
        headerService.header = { title: 'Block No. 19', headerIcon: { icon: "chevron_left", } }

        this.LoadAnswerOptions();
    }

    LoadAnswerOptions(){
      
      this.AnswerOptions.push({
        Option: "A",
        Desc: "win",
        Class: "abc"
      },
      {
        Option: "B",
        Desc: "winning",
        Class: "abc"
      },
      {
        Option: "C",
        Desc: "won",
        Class: "abc"
      });

      this.Scores = JSON.parse(sessionStorage.getItem('Scores'));

      let Question: any = {};
      let Option: any = {};

      Question = this.Scores.filter(i => i.Question === 19)[0];

      if(Question.IsCorrect !== null){
        Option = this.AnswerOptions.filter(i => i.Option === Question.ScannedAnswer)[0];
        Option.Class = Question.IsCorrect === true ? "correct abc" : "wrong abc";
      }

    }

    GoToQRScannerPage(){
      sessionStorage.setItem("QuestionNo", "19");
      this.router.navigate(['/questions/qr-scanner'])
    }

    ngOnInit() {
    }
}