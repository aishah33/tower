import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from '@angular/material';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';

@Component({
    selector: 'app-block-number',
    templateUrl: './block-number.component.html'
})
export class BlockNumberComponent implements OnInit {

  IsCompleted: boolean = false;

    constructor(public headerService: HeaderService, private http: HttpClient, private snackBar: MatSnackBar, private router: Router) {
      headerService.header = { title: 'Blocks', headerIcon: {icon: "chevron_left" } }
      
      this.SetScoreInSessionStorage();
    }

    SetScoreInSessionStorage(){
      let SetScores: boolean = sessionStorage.getItem('Scores') === null ? false : true;

      if(SetScores === false){
        let Scores: any = [];

        Scores.push({
          Question: 1,
          CorrectAnswer: "B",
          ScannedAnswer: "",
          IsCorrect: null
        },
        {
          Question: 2,
          CorrectAnswer: "B",
          ScannedAnswer: "",
          IsCorrect: null
        },
        {
          Question: 3,
          CorrectAnswer: "A",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 4,
          CorrectAnswer: "A",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 5,
          CorrectAnswer: "C",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 6,
          CorrectAnswer: "B",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 7,
          CorrectAnswer: "A",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 8,
          CorrectAnswer: "B",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 9,
          CorrectAnswer: "C",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 10,
          CorrectAnswer: "B",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 11,
          CorrectAnswer: "C",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 12,
          CorrectAnswer: "A",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 13,
          CorrectAnswer: "B",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 14,
          CorrectAnswer: "C",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 15,
          CorrectAnswer: "A",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 16,
          CorrectAnswer: "B",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 17,
          CorrectAnswer: "A",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 18,
          CorrectAnswer: "B",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 19,
          CorrectAnswer: "C",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 20,
          CorrectAnswer: "B",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 21,
          CorrectAnswer: "A",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 22,
          CorrectAnswer: "B",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 23,
          CorrectAnswer: "C",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 24,
          CorrectAnswer: "A",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 25,
          CorrectAnswer: "B",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 26,
          CorrectAnswer: "C",
          ScannedAnswer: "",
          IsCorrect: null 
        },
        {
          Question: 27,
          CorrectAnswer: "A",
          ScannedAnswer: "",
          IsCorrect: null 
        })

        sessionStorage.setItem('Scores', JSON.stringify(Scores));

      }else{
        let Scores: any = [];
        Scores = JSON.parse(sessionStorage.getItem("Scores"));
        this.IsCompleted = Scores.filter(i => i.IsCorrect === null).length > 0 ? false : true;

      }

    }

    Complete(){
      let Login: any = {};
      let Scores: any = [];
      let NoOfCorrectAnswers: number = 0;

      Login = JSON.parse(sessionStorage.getItem("TensesTowerLogin"));
      Scores = JSON.parse(sessionStorage.getItem("Scores"));
      NoOfCorrectAnswers = Scores.filter(i => i.IsCorrect === true).length;

      this.http.post(`${environment.ApiHost}${"/api/Registration/InsertScore"}`,{
        RegisterId: Login.id,
        Score: NoOfCorrectAnswers
      }).subscribe((data =>{
        let Insert: any = null;
        Insert = data;

        if(Insert == true){
          this.router.navigate(['/questions/score']);
        }else{
          this.snackBar.open('Score insertion unsuccessful', 'Dismiss!', { duration: 2000 });
        }

      }), err => console.error(err))


    }

    ngOnInit() {}
}