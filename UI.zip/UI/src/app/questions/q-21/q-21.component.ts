import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-q-21',
    templateUrl: './q-21.component.html'
})
export class Q21Component implements OnInit {

  AnswerOptions: any = [];
  Scores: any = [];

    constructor(public headerService: HeaderService, private router : Router) {
        headerService.header = { title: 'Block No. 21', headerIcon: { icon: "chevron_left", } }
    

        this.LoadAnswerOptions();
      }

        LoadAnswerOptions(){
      
          this.AnswerOptions.push({
            Option: "A",
            Desc: "left",
            Class: "abc"
          },
          {
            Option: "B",
            Desc: "leave",
            Class: "abc"
          },
          {
            Option: "C",
            Desc: "will leave",
            Class: "abc"
          });
    
          this.Scores = JSON.parse(sessionStorage.getItem('Scores'));
    
          let Question: any = {};
          let Option: any = {};
    
          Question = this.Scores.filter(i => i.Question === 21)[0];
    
          if(Question.IsCorrect !== null){
            Option = this.AnswerOptions.filter(i => i.Option === Question.ScannedAnswer)[0];
            Option.Class = Question.IsCorrect === true ? "correct abc" : "wrong abc";
          }
    
        }
    
        GoToQRScannerPage(){
          sessionStorage.setItem("QuestionNo", "21");
          this.router.navigate(['/questions/qr-scanner'])
        }
   

    ngOnInit() {
    }
}