import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-score',
  templateUrl: './score.component.html'
})
export class ScoreComponent implements OnInit {

  Score: number = 0;
  PreviousScore: number = 0;

  constructor(public headerService: HeaderService, private router: Router, private http: HttpClient) {
    headerService.header = { title: 'Score', headerIcon: { icon: "chevron_left" } }
    this.GetScores();
    this.GetPreviousScore();
  }

  GetScores(){
    let Scores: any = [];
    Scores = JSON.parse(sessionStorage.getItem("Scores"));
    this.Score = (!jQuery.isEmptyObject(this.Score)) ? Scores.filter(i => i.IsCorrect === true).length : 0;
  }

  GetPreviousScore(){
    let Login: any = {};
    Login = JSON.parse(sessionStorage.getItem("TensesTowerLogin"));

    this.http.post(`${environment.ApiHost}${"/api/Registration/GetPreviousScore"}`,{
      RegisterID: Login.id
    }).subscribe((data =>{
      let Score: any = {};
      Score = data;
      this.PreviousScore = Score !== null ? Score.score : 0;
    }), err => console.error(err));
  }

  GoToHomePage() {
    this.router.navigate(['/home/homepage']);
    sessionStorage.removeItem("Scores");
  }

  ngOnInit() { }

}