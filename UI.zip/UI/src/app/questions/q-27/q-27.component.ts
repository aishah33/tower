import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-q-27',
    templateUrl: './q-27.component.html'
})
export class Q27Component implements OnInit {

  AnswerOptions: any = [];
  Scores: any = [];

    constructor(public headerService: HeaderService, private router : Router) {
        headerService.header = { title: 'Block No. 27', headerIcon: { icon: "chevron_left", } }

        this.LoadAnswerOptions();
    }

    LoadAnswerOptions(){
      
      this.AnswerOptions.push({
        Option: "A",
        Desc: "will finish",
        Class: "abc"
      },
      {
        Option: "B",
        Desc: "am finished",
        Class: "abc"
      },
      {
        Option: "C",
        Desc: "finish",
        Class: "abc"
      });

      this.Scores = JSON.parse(sessionStorage.getItem('Scores'));

      let Question: any = {};
      let Option: any = {};

      Question = this.Scores.filter(i => i.Question === 27)[0];

      if(Question.IsCorrect !== null){
        Option = this.AnswerOptions.filter(i => i.Option === Question.ScannedAnswer)[0];
        Option.Class = Question.IsCorrect === true ? "correct abc" : "wrong abc";
      }

    }

    GoToQRScannerPage(){
      sessionStorage.setItem("QuestionNo", "27");
      this.router.navigate(['/questions/qr-scanner'])
    }

    ngOnInit() {
    }
}