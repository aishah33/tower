import { Component, OnInit, ViewChild } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { ZXingScannerComponent } from '@zxing/ngx-scanner';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';

@Component({
    selector: 'app-qr-scanner',
    templateUrl: './qr-scanner.component.html'
})
export class QrScannerComponent implements OnInit {
    @ViewChild('scanner') scanner: ZXingScannerComponent;
    hasCameras = false;
    noOfScanned: number = 0;
    hasPermission: boolean;
    availableDevices: MediaDeviceInfo[];
    selectedDevice: MediaDeviceInfo;
    AuthCode: any = null;
    QuestionNo: string = "";
    Scores: any = [];

    constructor(public headerService: HeaderService, private snackBar: MatSnackBar, private router: Router) {
        headerService.header = {
            title: 'Scan QR Code',
            headerIcon: {
              icon: "chevron_left",
            }
          }

          this.GetQuestionNo();

    }

    GetQuestionNo(){
        this.QuestionNo = sessionStorage.getItem("QuestionNo");

        this.Scores = JSON.parse(sessionStorage.getItem('Scores'));

        if(this.QuestionNo === null){
          this.router.navigate(['/questions/block-number'])
        }else{
            sessionStorage.removeItem('QuestionNo');
        }
    }

    ngOnInit() {
      this.QRScan();
    }

    QRScan() {

      this.scanner.camerasFound.subscribe((devices: MediaDeviceInfo[]) => {

          this.hasCameras = true;
          this.availableDevices = devices;

          for (const device of devices) {
              if (/back|rear|environment/gi.test(device.label)) {
                  this.scanner.changeDevice(device);
                  this.selectedDevice = device;
                  break;
              }
          }

      });

      this.scanner.camerasNotFound.subscribe((devices: MediaDeviceInfo[]) => {
          console.error('An error has occurred when trying to enumerate your video-stream-enabled devices.');
      });

      this.scanner.permissionResponse.subscribe((answer: boolean) => {

          this.hasPermission = answer;

          if (answer === undefined) {

              this.snackBar.open('Waiting for permissions.If your device does not has cameras, no permissions will be asked.', 'Dismiss!', {
                  duration: 2500
              });

          } else if (answer === false) {

              this.snackBar.open('Denied camera access for scanning.', 'Dismiss!', {
                  duration: 2500
              });

          }


      });

  }

  QRQuickPay(AuthCode: any) {

    this.AuthCode = AuthCode;

    if (this.AuthCode !== null) {
        this.snackBar.open('QR Code successfully scanned', 'Dismiss', { duration: 2000 });
        
        let Score = this.Scores.filter(i => i.Question === parseInt(this.QuestionNo))[0];
        Score.ScannedAnswer = AuthCode;
        Score.IsCorrect = (Score.ScannedAnswer == Score.CorrectAnswer) ? true: false;
        sessionStorage.setItem("Scores", JSON.stringify(this.Scores));

        this.router.navigate(['/questions/q-'+ this.QuestionNo]);
    }

}

handleQrCodeResult(resultString: string) {

    this.noOfScanned += 1;

    if (this.noOfScanned === 1) {
        this.QRQuickPay(resultString);
    }

}

onDeviceSelectChange(selectedValue: string) {
    this.selectedDevice = this.scanner.getDeviceById(selectedValue);
}

}