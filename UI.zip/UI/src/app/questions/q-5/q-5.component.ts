import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-q-5',
    templateUrl: './q-5.component.html'
})
export class Q5Component implements OnInit {

  AnswerOptions: any = [];
  Scores: any = [];

    constructor(public headerService: HeaderService, private router: Router) {
        headerService.header = { title: 'Block No. 5', headerIcon: { icon: "chevron_left", }  }

        this.LoadAnswerOptions();
    }

    LoadAnswerOptions(){
      
      this.AnswerOptions.push({
        Option: "A",
        Desc: "goes",
        Class: "abc"
      },
      {
        Option: "B",
        Desc: "go",
        Class: "abc"
      },
      {
        Option: "C",
        Desc: "is going",
        Class: "abc"
      });

      this.Scores = JSON.parse(sessionStorage.getItem('Scores'));

      let Question: any = {};
      let Option: any = {};

      Question = this.Scores.filter(i => i.Question === 5)[0];

      if(Question.IsCorrect !== null){
        Option = this.AnswerOptions.filter(i => i.Option === Question.ScannedAnswer)[0];
        Option.Class = Question.IsCorrect === true ? "correct abc" : "wrong abc";
      }

    }

    GoToQRScannerPage(){
      sessionStorage.setItem("QuestionNo", "5");
      this.router.navigate(['/questions/qr-scanner'])
    }

    ngOnInit() {
    }
}