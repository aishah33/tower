import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-q-23',
    templateUrl: './q-23.component.html'
})
export class Q23Component implements OnInit {

  AnswerOptions: any = [];
  Scores: any = [];

    constructor(public headerService: HeaderService, private router : Router) {
        headerService.header = { title: 'Block No. 23', headerIcon: { icon: "chevron_left", } }

        this.LoadAnswerOptions();
    }

    LoadAnswerOptions(){
      
      this.AnswerOptions.push({
        Option: "A",
        Desc: "cook",
        Class: "abc"
      },
      {
        Option: "B",
        Desc: "cooking",
        Class: "abc"
      },
      {
        Option: "C",
        Desc: "cooks",
        Class: "abc"
      });

      this.Scores = JSON.parse(sessionStorage.getItem('Scores'));

      let Question: any = {};
      let Option: any = {};

      Question = this.Scores.filter(i => i.Question === 23)[0];

      if(Question.IsCorrect !== null){
        Option = this.AnswerOptions.filter(i => i.Option === Question.ScannedAnswer)[0];
        Option.Class = Question.IsCorrect === true ? "correct abc" : "wrong abc";
      }

    }

    GoToQRScannerPage(){
      sessionStorage.setItem("QuestionNo", "23");
      this.router.navigate(['/questions/qr-scanner'])
    }

    ngOnInit() {
    }
}