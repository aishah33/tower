import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-q-24',
    templateUrl: './q-24.component.html'
})
export class Q24Component implements OnInit {

  AnswerOptions: any = [];
  Scores: any = [];

    constructor(public headerService: HeaderService, private router: Router) {
        headerService.header = { title: 'Block No. 24', headerIcon: { icon: "chevron_left", } }

        this.LoadAnswerOptions();
    }

    LoadAnswerOptions(){
      
      this.AnswerOptions.push({
        Option: "A",
        Desc: "works",
        Class: "abc"
      },
      {
        Option: "B",
        Desc: "work",
        Class: "abc"
      },
      {
        Option: "C",
        Desc: "working",
        Class: "abc"
      });

      this.Scores = JSON.parse(sessionStorage.getItem('Scores'));

      let Question: any = {};
      let Option: any = {};

      Question = this.Scores.filter(i => i.Question === 24)[0];

      if(Question.IsCorrect !== null){
        Option = this.AnswerOptions.filter(i => i.Option === Question.ScannedAnswer)[0];
        Option.Class = Question.IsCorrect === true ? "correct abc" : "wrong abc";
      }

    }

    GoToQRScannerPage(){
      sessionStorage.setItem("QuestionNo", "24");
      this.router.navigate(['/questions/qr-scanner'])
    }

    ngOnInit() {
    }
}