import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-q-1',
    templateUrl: './q-1.component.html'
})
export class Q1Component implements OnInit {

  AnswerOptions: any = [];
  Scores: any = [];

    constructor(public headerService: HeaderService, private router: Router) {
        headerService.header = { title: 'Block No. 1', headerIcon: {icon: "chevron_left" } };
        this.LoadAnswerOptions();
    }

    LoadAnswerOptions(){
      
      this.AnswerOptions.push({
        Option: "A",
        Desc : "collect",
        Class: "abc"
      },
      {
        Option: "B",
        Desc: "collects",
        Class: "abc"
      },
      {
        Option: "C",
        Desc: "is collected",
        Class : "abc"
      });

      this.Scores = JSON.parse(sessionStorage.getItem('Scores'));

      let Question: any = {};
      let Option: any = {};

      Question = this.Scores.filter(i => i.Question === 1)[0];

      if(Question.IsCorrect !== null){
        Option = this.AnswerOptions.filter(i => i.Option === Question.ScannedAnswer)[0];
        Option.Class = Question.IsCorrect === true ? "correct abc" : "wrong abc";
      }

    }

    GoToQRScannerPage(){
      sessionStorage.setItem("QuestionNo", "1");
      this.router.navigate(['/questions/qr-scanner'])
    }

    ngOnInit() {
    }
}