import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { HeaderService } from '../../shared/header.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
})
export class ListComponent implements OnInit {

  constructor(public headerService: HeaderService, private _snackBar: MatSnackBar) {
    headerService.header = null
  }

  twoRow = `        
  <mat-list class="two-n-three-row-list">
  <mat-list-item class="item" matRipple >
    <img mat-list-avatar class="list-img" src="'./../../../../assets/images/background/profile-bg.jpg">
    <div class="title" mat-line>Project Name</div>
    <div class="desc" mat-line>Line Description </div>
    <mat-icon>chevron_right</mat-icon>
    <mat-divider></mat-divider>
  </mat-list-item>
</mat-list> `

threeRow = ` 
<mat-list class="two-n-three-row-list">
<mat-list-item class="item" matRipple>
  <img mat-list-avatar class="list-img" src="'./../../../../assets/images/background/profile-bg.jpg">
  <div class="title" mat-line>Project Name</div>
  <div class="desc" mat-line>Line Description </div>
  <div class="desc" mat-line>Line Description </div>
  <mat-icon>chevron_right</mat-icon>
  <mat-divider></mat-divider>
</mat-list-item>
</mat-list>`

singleRow = ` 
<mat-list class="one-row-list">
<mat-list-item class="item" matRipple>
  <img mat-list-avatar src="'./../../../../assets/images/background/profile-bg.jpg">
  <div class="title" mat-line>Project Name</div>
  <mat-icon>chevron_right</mat-icon>
  <mat-divider></mat-divider>
</mat-list-item>
</mat-list>`

  ngOnInit() {
  }

  copyToClipboard(text) {
    var dummy = document.createElement("textarea");
    console.log(text)
    document.body.appendChild(dummy);
   
    if(text == 'twoRow'){
      dummy.value = this.twoRow
    }else if(text == 'threeRow'){
      dummy.value = this.threeRow
    }else if(text == 'singleRow'){
      dummy.value = this.singleRow
    }else{
      dummy.value = "Not Found"
    }
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
    this._snackBar.open("Copied", "", {
      duration: 2000,
    });
 
  }
}
