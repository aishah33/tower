import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styles: []
})
export class CardComponent implements OnInit {
  cardHtml = ` 
  <mat-card class="detail-card">
  <div class="info-container" fxLayout="row wrap">
    <div fxFlex="100" class="info-item">
      <div class="info-title">
        Info Title
      </div>
      <div class="info-desc">
        Info Description
      </div>
    </div>
  </div>
  <div class="divider"></div>
  <div class="info-container" fxLayout="row wrap">
      <div fxFlex="50" class="info-item">
        <div class="info-title">
          Info Title
        </div>
        <div class="info-desc">
          Info Description
        </div>
      </div>
      <div fxFlex="50" class="info-item with-top">
        <div class="info-title">
          Info Title
        </div>
        <div class="info-desc">
          Info Description
        </div>
      </div>
    </div>
</mat-card>`
  cardDescHtml = `
<mat-card class="detail-card">
<div class="card-title">
  Title
</div>
<div class="card-desc">
  Card Description
</div>
<div class="info-container" fxLayout="row wrap">
  <div fxFlex="100" class="info-item">
    <div class="info-title">
      Info Title
    </div>
    <div class="info-desc">
      Info Description
    </div>
  </div>
</div>
</mat-card>`;

  cardImageHtml = `
<mat-card class="detail-card">
<div class="info-container" fxLayout="row wrap">
  <div fxFlex="100" class="info-item">
    <div class="info-title">
      Info Title
    </div>
    <div class="info-desc">
      <div class="img-item">
        <img src="../../../assets/images/background/weatherbg.jpg">
      </div>
    </div>
  </div>
  <div fxFlex="50" class="info-item">
    <div class="info-title">
      Info Title
    </div>
    <div class="info-desc">
      <div class="img-item">
        <img src="../../../assets/images/background/weatherbg.jpg">
      </div>
    </div>
  </div>
  <div fxFlex="50" class="info-item">
    <div class="info-title">
      Info Title
    </div>
    <div class="info-desc">
      <div class="img-item">
        <img src="../../../assets/images/background/weatherbg.jpg">
      </div>
    </div>
  </div>
</div>
</mat-card>`;

cardExpandHtml = `  
<mat-expansion-panel class="detail-card expansion">
<mat-expansion-panel-header [collapsedHeight]="'100%'" [expandedHeight]="'100%'">
  <mat-list class="two-n-three-row-list">
    <mat-list-item class="item">

      <div class="title" mat-line>Title
      </div>
      <div class="desc" mat-line>Description</div>
    </mat-list-item>
  </mat-list>
</mat-expansion-panel-header>
<div class="info-container" fxLayout="row wrap" >
  <div fxFlex="100" class="info-item">
    <div class="info-title">
      Project Name
    </div>
    <div class="info-desc">
      Example
    </div>
  </div>   
</div>
</mat-expansion-panel>`

constructor(public headerService: HeaderService, private _snackBar: MatSnackBar) {
  headerService.header = null
}

  ngOnInit() {
  }


  copyToClipboard(text) {
    var dummy = document.createElement("textarea");
    // to avoid breaking orgain page when copying more words
    // cant copy when adding below this code
    // dummy.style.display = 'none'
    console.log(text)
    document.body.appendChild(dummy);
    //Be careful if you use texarea. setAttribute('value', value), which works with "input" does not work with "textarea". – Eduard
    if(text == 'cardHtml'){
      dummy.value = this.cardHtml
    }else if(text == 'cardDescHtml') {
      dummy.value = this.cardDescHtml
    }else if(text == 'cardImageHtml') {
      dummy.value = this.cardImageHtml
    }else if(text == 'cardExpandHtml') {
      dummy.value = this.cardExpandHtml
    }else{
      dummy.value = "Not Found"
    }
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);

    this._snackBar.open("Copied", "", {
      duration: 2000,
    });
  }

}
