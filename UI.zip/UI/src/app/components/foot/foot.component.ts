import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { HeaderService } from '../../shared/header.service';


@Component({
  selector: 'app-foot',
  templateUrl: './foot.component.html',
  styles: []
})
export class FootComponent implements OnInit {
  stepFooter = ` 
<div class="footer-menu">
  <button class="back-btn" mat-button >Back</button>
  <button class="next-btn" type="submit" mat-raised-button color="primary">Next</button>
</div>
`
  pageFooterDisable = `
   <div fxLayout="row wrap" class="footer-menu">
  <div matRipple matRippleRadius="0" matRippleCentered="true" matRippleUnbounded="true" fxFlex="25">
    <mat-icon class="footer-icon disable">image</mat-icon>
    <div class="footer-title disable">GALLERY</div>
  </div>

  <div matRipple matRippleRadius="0" matRippleCentered="true" matRippleUnbounded="true" fxFlex="25">
    <mat-icon class="footer-icon disable">select_all</mat-icon>
    <div class="footer-title disable">UNITS</div>
  </div>

  <div matRipple matRippleRadius="0" matRippleCentered="true" matRippleUnbounded="true" fxFlex="25">
    <mat-icon class="footer-icon disable ">gavel</mat-icon>
    <div class="footer-title disable ">SALESCHART</div>
  </div>

  <div matRipple matRippleRadius="0" matRippleCentered="true" matRippleUnbounded="true" fxFlex="25">
    <mat-icon class="footer-icon disable">import_contacts</mat-icon>
    <div class="footer-title disable">BROCHURE</div>
  </div>
</div>`
  pageFooter = ` 
  <div fxLayout="row wrap" class="footer-menu">
  <div matRipple matRippleRadius="30" matRippleCentered="true" matRippleUnbounded="true" fxFlex="25">
      <mat-icon class="footer-icon">image</mat-icon>
      <div class="footer-title">GALLERY</div>
  </div>

  <div matRipple matRippleRadius="30" matRippleCentered="true" matRippleUnbounded="true" fxFlex="25">
      <mat-icon class="footer-icon">select_all</mat-icon>
      <div class="footer-title">UNITS</div>
  </div>

  <div matRipple matRippleRadius="30" matRippleCentered="true" matRippleUnbounded="true" fxFlex="25">
      <mat-icon class="footer-icon ">gavel</mat-icon>
      <div class="footer-title ">SALESCHART</div>
  </div>

  <div matRipple matRippleRadius="30" matRippleCentered="true" matRippleUnbounded="true" fxFlex="25">
      <mat-icon class="footer-icon">import_contacts</mat-icon>
      <div class="footer-title">BROCHURE</div>
  </div>
</div>`

  constructor(public headerService: HeaderService, private _snackBar: MatSnackBar) {
    headerService.header = null
  }

  ngOnInit() {
  }

  copyToClipboard(text) {
    var dummy = document.createElement("textarea");
    console.log(text)
    document.body.appendChild(dummy);
    if(text == 'pageFooter'){
      dummy.value = this.pageFooter
    }else if(text == 'pageFooterDisable'){
      dummy.value = this.pageFooterDisable
    }else if(text == 'stepFooter'){
      dummy.value = this.stepFooter
    }else{
      dummy.value = "Not Found"
    }
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
    this._snackBar.open("Copied", "", {
      duration: 2000,
    });
 
  }


}
