import * as $ from 'jquery';
import { MediaMatcher } from '@angular/cdk/layout';
import {
  ChangeDetectorRef,
  Component,
  NgZone,
  OnDestroy,
  ViewChild,
  HostListener,
  Directive,
  AfterViewInit,
  OnInit
} from '@angular/core';
import { MenuItems } from '../../shared/menu-items/menu-items';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { MatDialog, MatSidenav } from '@angular/material';
import { MatBottomSheet } from '@angular/material';
import { BottomSheet } from '../../shared/dialog/bottomSheet/bottom-sheet';
import { SharedService } from '../../shared/shared.services';
import { SnackBarService } from '../../shared/snack.bar.service';


import { routerTransition } from '../../shared/animations';
import { NavigationService } from '../../shared/navigation.service';

@Component({
  selector: 'app-full-layout',
  templateUrl: 'full.component.html',
  styleUrls: [],
  providers: [MatBottomSheet],
  animations: [
    routerTransition()
  ]
})
export class FullComponent implements OnDestroy, AfterViewInit, OnInit {

  @ViewChild('snav') public snav: MatSidenav;

  mobileQuery: MediaQueryList;
  minisidebar: boolean;
  showHide: boolean;
  sidebarOpened;

  public config: PerfectScrollbarConfigInterface = {};
  private _mobileQueryListener: () => void;

  constructor(
    private navigationService: NavigationService,
    private bottomSheet: MatBottomSheet,
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    public menuItems: MenuItems,
    public dialog: MatDialog,
    public sharedService: SharedService,
    private snackBarService: SnackBarService

  ) {
    this.mobileQuery = media.matchMedia('(min-width: 768px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
  }

  getRouteAnimation(outlet) {
    return this.navigationService.animationValue;
  }

  
  openBS() {
    event.stopPropagation();
    var a = this.bottomSheet.open(BottomSheet, { data: 1 });
    a.afterDismissed().subscribe((x) => {
    });
  }
 
  ngOnInit() {
    this.sharedService.sideNav = this.snav;
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }
  
  ngAfterViewInit() {
  }

  dialogs() {
    this.snackBarService.show("haha", "Undo").subscribe(() => {
      console.log("ahhahaaha");
    });
    this.snackBarService.show("haha");
    //this.snackBarService.show("sohai");
    /* var a =  this.bottomSheet.open(BottomSheet,{data:1});
    a.afterDismissed().subscribe((x)=>{
      console.log(x);
    }); */
    /* const dialogRef = this.dialog.open(ConfirmationDialog, {
      width: '250px',
      data : {showTextBox:true}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
    }); */
  }



}
