import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Validators, FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  Login: any = {};
  UserName = new FormControl('', [Validators.required, Validators.required]);
  Password = new FormControl('', [Validators.required, Validators.required]);

  constructor(private snackBar: MatSnackBar, private http: HttpClient, private router: Router) {
    this.GetTensesTowerLoginSession();
  }

  GetTensesTowerLoginSession(){
    this.Login = JSON.parse(sessionStorage.getItem('TensesTowerLogin'));

    if(jQuery.isEmptyObject(this.Login)) this.router.navigate(['authentication/login']); else this.router.navigate(['/home/homepage']);
}
  ngOnInit() {}

  OnSubmit() {
    this.UserName.markAsTouched();
    this.Password.markAsTouched();

    if(this.UserName.invalid){
      this.UserName.markAsTouched();
      this.snackBar.open('User Name is required', 'Dimiss!', { duration: 2000 });
      return;
    }

    if(this.Password.invalid){
      this.Password.markAsTouched();
      this.snackBar.open('Password is required', 'Dimiss!', { duration: 2000 });
      return;
    }

    this.http.post(`${environment.ApiHost}${"/api/Login/Login"}`,{
      UserName: this.UserName.value,
      Password: this.Password.value
    }).subscribe((data =>{
      let Login: any = null;
      Login = data;

      
      if(Login != null){
        let LoginQueryParams: any = {};
        LoginQueryParams = { id: Login.id, FullName: Login.fullName, School: Login.school };
        sessionStorage.setItem("TensesTowerLogin", JSON.stringify(LoginQueryParams));
        
        this.router.navigate(['/home/homepage']);
      }else{
        this.snackBar.open('User Name or Password is incorrect', 'Dimiss!', { duration: 4000 });
        return
      }

    }), err => console.error(err));
  }

}
