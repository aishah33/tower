import { Component, AfterViewInit } from '@angular/core';
import { SharedService } from '../../shared/shared.services';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material';


@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
})
export class ResetPasswordComponent implements AfterViewInit {
  hide = true;
  
  myform: FormGroup;
  oldPassCtrl: FormControl;
  newPassCtrl: FormControl;
  confirmPassCtrl: FormControl;
  userData: any = {};
  Observable: any;
  constructor(private router: Router, private http: HttpClient,private sharedService: SharedService,private snackBar: MatSnackBar) {
    sharedService.header.title = "Change Password";
    sharedService.header.menu = 3;

   // this.userData=this.profileService.result;
 
    
    //this.userData.UserId = this.tokenService.UserID;
    //this.userData.loginEmail=this.profileService.result.loginEmail;

  }


  ngAfterViewInit() {
  

  }



}


