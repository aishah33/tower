import { Component, AfterViewInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material';
import { HeaderService } from '../../../app/shared/header.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';




@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',

})
export class EditProfileComponent implements AfterViewInit {


  constructor(public headerService: HeaderService, private snackbar: MatSnackBar) {
    headerService.header = {
      title: "Edit Profile",
      headerIcon: {
        icon: "close"
      },
      headerButton:[
        {
          title: "SAVE",
          action: {
            function:()=>{
              window.history.back()
              this.editSuccessSB()
            }
          }
        }
      ]

    }




  }
  ngAfterViewInit() {

  }

  editSuccessSB(){
    this.snackbar.open("Edit Successful", "Dismiss")
  }

}

