import { Routes } from '@angular/router';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { FilterComponent } from './filter/filter.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';




export const OthersRoutes: Routes = [

{
    path: 'my-profile',
    component: MyProfileComponent
  },{
    path: 'edit-profile',
    component: EditProfileComponent
  },  {
    path: 'reset-password',
    component: ResetPasswordComponent
  },{
    path: 'filter',
    component: FilterComponent
  }
];
