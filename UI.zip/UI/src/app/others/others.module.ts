import 'hammerjs';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DemoMaterialModule } from '../demo-material-module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { OthersRoutes } from './others.routing';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FilterComponent } from './filter/filter.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';


@NgModule({
  imports: [
    CommonModule,
    DemoMaterialModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(OthersRoutes)

  ], entryComponents: [
 
  ],
  declarations: [
    MyProfileComponent,
    EditProfileComponent,
    FilterComponent,
    ResetPasswordComponent,
    
   
  ]
})

export class OthersModule {


}
