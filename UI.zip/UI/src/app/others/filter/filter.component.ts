import { Component, AfterViewInit } from '@angular/core';
import { SharedService } from '../../shared/shared.services';
import { HeaderService } from '../../shared/header.service';


@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html'
})
export class FilterComponent implements AfterViewInit {

  constructor(public headerService: HeaderService) {
    headerService.header = {
      title: "Filter",
      headerIcon: {
        icon: "close"
      },
      headerButton: [
        {
          title: "SAVE",
          action: {
            function: () => {
              window.history.back()
            }
          }
        }
      ]

    }

  }
  ngAfterViewInit() {

  }




}

