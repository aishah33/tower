import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-homepage',
    templateUrl: './homepage.component.html'
})
export class HomepageComponent implements OnInit {
    Login: any = {};

    constructor(public headerService: HeaderService, private router: Router) {
        headerService.header = null;

        this.GetTensesTowerLoginSession();
    }

    GetTensesTowerLoginSession(){
        this.Login = JSON.parse(sessionStorage.getItem('TensesTowerLogin'));

        if(jQuery.isEmptyObject(this.Login)){
            this.router.navigate(['authentication/login']); 
            sessionStorage.clear();
        } 
    }

    GoToQuestionPage(){
        this.router.navigate(['/questions/block-number']);
    }

    GoToScorePage(){
        this.router.navigate(['/questions/score']);   
    }
    
    GoToInstructionsPage(){
        this.router.navigate(['/questions/instructions']);   
    }

    ngOnInit() {}
}
