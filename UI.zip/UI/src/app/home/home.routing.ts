import { Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';


export const HomeRoutes: Routes = [

      {
        path: 'homepage',
        component: HomepageComponent,
      }   
 
];
