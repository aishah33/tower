import 'hammerjs';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DemoMaterialModule } from '../demo-material-module';
import { FlexLayoutModule } from '@angular/flex-layout';

import { DashboardsRoutes } from './dashboards.routing';
import { DashboardComponent } from './dashboard/dashboard.component';

import { FooterComponent } from '../layouts/full/footer/footer.component';
import { NavigationService } from '../shared/navigation.service';
import { PageDetailComponent } from './pages/page-detail/page-detail.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  imports: [
    CommonModule,
    DemoMaterialModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(DashboardsRoutes)
  ],
  declarations: [
    DashboardComponent,
    PageDetailComponent,
    FooterComponent],
  providers: [
    NavigationService
  ],
})
export class DashboardsModule { }
