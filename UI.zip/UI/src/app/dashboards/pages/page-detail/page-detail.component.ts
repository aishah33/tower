import { Component, AfterViewInit } from '@angular/core';

import { SharedService } from '../../../shared/shared.services';
import { SnackBarService } from '../../../shared/snack.bar.service';
import { HeaderService } from '../../../shared/header.service';





@Component({
  selector: 'app-page-detail',
  templateUrl: './page-detail.component.html',
})
export class PageDetailComponent implements AfterViewInit {
  constructor(public sharedService: SharedService, private snackBarService:SnackBarService, public headerService:HeaderService){
    headerService.header = {
      title: "Page Detail",
      headerIcon: {
        icon: "close",
      },
      headerButton: [
        {
          title: "SAVE",
          action: {
            function: () => {
              window.history.back();
              this.successSB()
            }
          }
        }
      ]
    };
  }
  
  ngAfterViewInit() {
  }

  successSB(){
    this.snackBarService.show("Create Successfully","Undo").subscribe(() => {
    }); 
  }

}
