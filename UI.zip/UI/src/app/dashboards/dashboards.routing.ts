import { Routes } from '@angular/router';

import { DashboardComponent } from './dashboard/dashboard.component';
import { PageDetailComponent } from './pages/page-detail/page-detail.component';

export const DashboardsRoutes: Routes = [

      {
        path: 'dashboard',
        component: DashboardComponent,
      },   
      {
        path: 'page-detail',
        component: PageDetailComponent,
      }
 
];
