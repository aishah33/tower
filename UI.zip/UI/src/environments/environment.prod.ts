export const environment = {
  production: true,
  ApiHost: "http://localhost:53714",
  dialogFlow: {
    chatBot: 'c68f84b6805646a59eeee6d77e780303'
  }
};
