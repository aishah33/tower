export const Enivroments = {
  Development:{
    production: false,
    ApiHost: "http://localhost:53714",
    dialogFlow: {
      chatBot: 'c68f84b6805646a59eeee6d77e780303'
    }
  },
  Staging:{
    production: false,
    ApiHost: "",
    dialogFlow: {
      chatBot: 'c68f84b6805646a59eeee6d77e780303'
    }
  },
  Production:{
    production: true,
    ApiHost: "",
    dialogFlow: {
      chatBot: 'c68f84b6805646a59eeee6d77e780303'
    }
  }
}

export const environment = Enivroments.Development;

