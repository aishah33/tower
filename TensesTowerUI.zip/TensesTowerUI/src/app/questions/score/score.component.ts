import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-score',
    templateUrl: './score.component.html'
})
export class ScoreComponent implements OnInit {

    constructor(public headerService: HeaderService) {
        headerService.header = {
            title: 'Score',
            headerIcon: {
              icon: "chevron_left",
            }
          }
    }

    ngOnInit() {
    }
}