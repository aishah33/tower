import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';

@Component({
    selector: 'app-q-9',
    templateUrl: './q-9.component.html'
})
export class Q9Component implements OnInit {

    constructor(public headerService: HeaderService) {
        headerService.header = {
            title: 'Block No. 9',
            headerIcon: {
              icon: "chevron_left",
            }
          }
    }

    ngOnInit() {
    }
}