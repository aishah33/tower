import { Routes } from '@angular/router';
import { BlockNumberComponent } from './block-number/block-number.component';
import { ScoreComponent } from './score/score.component';
import { Q1Component } from './q-1/q-1.component';
import { Q2Component } from './q-2/q-2.component';
import { Q3Component } from './q-3/q-3.component';
import { Q4Component } from './q-4/q-4.component';
import { Q5Component } from './q-5/q-5.component';
import { Q6Component } from './q-6/q-6.component';
import { Q7Component } from './q-7/q-7.component';
import { Q8Component } from './q-8/q-8.component';
import { Q9Component } from './q-9/q-9.component';
import { Q10Component } from './q-10/q-10.component';
import { Q11Component } from './q-11/q-11.component';
import { Q12Component } from './q-12/q-12.component';
import { Q13Component } from './q-13/q-13.component';
import { Q14Component } from './q-14/q-14.component';
import { Q15Component } from './q-15/q-15.component';
import { Q16Component } from './q-16/q-16.component';
import { Q17Component } from './q-17/q-17.component';
import { Q18Component } from './q-18/q-18.component';
import { Q19Component } from './q-19/q-19.component';
import { Q20Component } from './q-20/q-20.component';
import { Q21Component } from './q-21/q-21.component';
import { Q22Component } from './q-22/q-22.component';
import { Q23Component } from './q-23/q-23.component';
import { Q24Component } from './q-24/q-24.component';
import { Q25Component } from './q-25/q-25.component';
import { Q26Component } from './q-26/q-26.component';
import { Q27Component } from './q-27/q-27.component';



export const QuestionsRoutes: Routes = [

      {
        path: 'block-number',
        component: BlockNumberComponent,
      },
      {
        path: 'score',
        component: ScoreComponent,
      },
      {
        path: 'q-1',
        component: Q1Component,
      },
      {
        path: 'q-2',
        component: Q2Component,
      },
      {
        path: 'q-3',
        component: Q3Component,
      } ,
      {
        path: 'q-4',
        component: Q4Component,
      },
      {
        path: 'q-5',
        component: Q5Component,
      } ,
      {
        path: 'q-6',
        component: Q6Component,
      },
      {
        path: 'q-7',
        component: Q7Component,
      },
      {
        path: 'q-8',
        component: Q8Component,
      },
      {
        path: 'q-9',
        component: Q9Component,
      },
      {
        path: 'q-10',
        component: Q10Component,
      },
      {
        path: 'q-11',
        component: Q11Component,
      },
      {
        path: 'q-12',
        component: Q12Component,
      },
      {
        path: 'q-13',
        component: Q13Component,
      },
      {
        path: 'q-14',
        component: Q14Component,
      },
      {
        path: 'q-15',
        component: Q15Component,
      },
      {
        path: 'q-16',
        component: Q16Component,
      },
      {
        path: 'q-17',
        component: Q17Component,
      },
      {
        path: 'q-18',
        component: Q18Component,
      },
      {
        path: 'q-19',
        component: Q19Component,
      },
      {
        path: 'q-20',
        component: Q20Component,
      },
      {
        path: 'q-21',
        component: Q21Component,
      },
      {
        path: 'q-22',
        component: Q22Component,
      },
      {
        path: 'q-23',
        component: Q23Component,
      },
      {
        path: 'q-24',
        component: Q24Component,
      },
      {
        path: 'q-25',
        component: Q25Component,
      },
      {
        path: 'q-26',
        component: Q26Component,
      },
      {
        path: 'q-27',
        component: Q27Component,
      }
 
];
