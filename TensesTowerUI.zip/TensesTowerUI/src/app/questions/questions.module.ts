import 'hammerjs';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DemoMaterialModule } from '../demo-material-module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NavigationService } from '../shared/navigation.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

 import { QuestionsRoutes } from './questions.routing';
 import { BlockNumberComponent } from './block-number/block-number.component';
 import { ScoreComponent } from './score/score.component';
import { Q2Component } from './q-2/q-2.component';
 import { Q3Component } from './q-3/q-3.component';
 import { Q4Component } from './q-4/q-4.component';
 import { Q5Component } from './q-5/q-5.component';
 import { Q6Component } from './q-6/q-6.component';
 import { Q7Component } from './q-7/q-7.component';
 import { Q8Component } from './q-8/q-8.component';
 import { Q9Component } from './q-9/q-9.component';
import { Q10Component } from './q-10/q-10.component';
import { Q11Component } from './q-11/q-11.component';
 import { Q12Component } from './q-12/q-12.component';
 import { Q13Component } from './q-13/q-13.component';
 import { Q14Component } from './q-14/q-14.component';
 import { Q15Component } from './q-15/q-15.component';
  import { Q16Component } from './q-16/q-16.component';
 import { Q17Component } from './q-17/q-17.component';
 import { Q18Component } from './q-18/q-18.component';
 import { Q19Component } from './q-19/q-19.component';
 import { Q20Component } from './q-20/q-20.component';
 import { Q21Component } from './q-21/q-21.component';
 import { Q22Component } from './q-22/q-22.component';
 import { Q23Component } from './q-23/q-23.component';
 import { Q24Component } from './q-24/q-24.component';
 import { Q25Component } from './q-25/q-25.component';
 import { Q26Component } from './q-26/q-26.component';
 import { Q27Component } from './q-27/q-27.component';
import { Q1Component } from './q-1/q-1.component';

@NgModule({
  imports: [
    CommonModule,
    DemoMaterialModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(QuestionsRoutes)
  ],
  declarations: [
  BlockNumberComponent,
   ScoreComponent,
   Q1Component,
   Q2Component,
   Q3Component,
   Q4Component,
   Q5Component,
   Q6Component,
   Q7Component,
   Q8Component,
   Q9Component,
   Q10Component,
   Q11Component,
   Q12Component,
   Q13Component,
   Q14Component,
   Q15Component,
   Q16Component,
   Q17Component,
   Q18Component,
   Q19Component,
   Q20Component,
   Q21Component,
   Q22Component,
   Q23Component,
   Q24Component,
   Q25Component,
   Q26Component,
   Q27Component

  ],
  providers: [
    NavigationService
  ],
})
export class QuestionsModule { }
