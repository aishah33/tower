import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';

@Component({
    selector: 'app-q-15',
    templateUrl: './q-15.component.html'
})
export class Q15Component implements OnInit {

    constructor(public headerService: HeaderService) {
        headerService.header = {
            title: 'Block No. 15',
            headerIcon: {
              icon: "chevron_left",
            }
          }
    }

    ngOnInit() {
    }
}