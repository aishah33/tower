import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';

@Component({
    selector: 'app-q-18',
    templateUrl: './q-18.component.html'
})
export class Q18Component implements OnInit {

    constructor(public headerService: HeaderService) {
        headerService.header = {
            title: 'Block No. 18',
            headerIcon: {
              icon: "chevron_left",
            }
          }
    }

    ngOnInit() {
    }
}