import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';

@Component({
    selector: 'app-q-8',
    templateUrl: './q-8.component.html'
})
export class Q8Component implements OnInit {

    constructor(public headerService: HeaderService) {
        headerService.header = {
            title: 'Block No. 8',
            headerIcon: {
              icon: "chevron_left",
            }
          }
    }

    ngOnInit() {
    }
}