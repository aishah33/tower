import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';

@Component({
    selector: 'app-q-23',
    templateUrl: './q-23.component.html'
})
export class Q23Component implements OnInit {

    constructor(public headerService: HeaderService) {
        headerService.header = {
            title: 'Block No. 23',
            headerIcon: {
              icon: "chevron_left",
            }
          }
    }

    ngOnInit() {
    }
}