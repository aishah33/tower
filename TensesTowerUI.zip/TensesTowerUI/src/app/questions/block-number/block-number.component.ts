import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-block-number',
    templateUrl: './block-number.component.html'
})
export class BlockNumberComponent implements OnInit {

    constructor(public headerService: HeaderService) {
        headerService.header = {
            title: 'Blocks',
            headerIcon: {
              icon: "chevron_left",
            }
          }
    }

    ngOnInit() {
    }
}