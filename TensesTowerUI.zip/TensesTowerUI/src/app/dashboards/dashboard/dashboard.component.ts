import { Component, AfterViewInit, ViewContainerRef } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { SharedService } from '../../shared/shared.services';
import { SnackBarService } from '../../shared/snack.bar.service';
import { ConfirmationDialog } from '../../shared/dialog/confirmation-dialog/confirmation-dialog';
import { MatDialog } from '@angular/material';
import { HeaderService } from '../../shared/header.service';
import Swiper from 'swiper';
import { PopupImg } from '../../shared/dialog/popup-img/popup-img';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
})
export class DashboardComponent implements AfterViewInit {
  value: String;
  name = "hellow";
  fontHtml = `  
  <p class="color-green">.color-green</p>
  <p class="color-red">.color-red</p>
  <p class="color-orange">.color-orange</p>
  <p class="color-grey">.color-grey</p>
  <p class="color-black">.color-black</p>`;

  searchHtml =`
  <form class="search-project">
  <input type="text" class="form-control" placeholder="Search project here ..." 
      name="searchText" autofocus #searchInput>
  <a class="cl-srh-btn" matRipple (click)="closeSearchProject()" aria-label="search">
      <i class="ti-close"></i>
  </a>
</form>
<mat-list class="search-bar">
  <mat-list-item>
      <span matLine>Project Listing</span>
      <button mat-icon-button aria-label="search" (click)="initSearchProject(); searchInput.focus();">
          <mat-icon>search</mat-icon>
      </button>
      <button mat-icon-button aria-label="tune" routerLink="/others/filter">
          <mat-icon>tune</mat-icon>
      </button>
  </mat-list-item>
</mat-list>`;

searchBackHtml =`
<form class="search-project ">
<input type="text" class="form-control" placeholder="Search project here ..." 
    name="searchText" autofocus #searchInput>
<a class="cl-srh-btn" matRipple (click)="closeSearchProject()" aria-label="search">
    <i class="ti-close"></i>
</a>
</form>
<mat-list class="search-bar with-back">
<mat-list-item>
  <mat-icon (click)="searchBack()" matRipple mat-list-icon>keyboard_backspace</mat-icon>
  <span matLine>Project Listing</span>
  <button mat-icon-button aria-label="search" (click)="initSearchProject(); searchInput.focus();">
    <mat-icon>search</mat-icon>
  </button>
  <button mat-icon-button aria-label="tune" routerLink="/others/filter">
    <mat-icon>tune</mat-icon>
  </button>
</mat-list-item>
</mat-list>`;

  searchTs = `
initSearchProject() {
    (<any>$('.search-project')).toggle(250);
}

closeSearchProject() {
    this.value = '';
    (<any>$('.search-project')).toggle(250);
}`;

searchBackTs = `
searchBack(){
  window.history.back();
}

initSearchProject() {
    (<any>$('.search-project')).toggle(250);
}

closeSearchProject() {
    this.value = '';
    (<any>$('.search-project')).toggle(250);
}`;

cookieHtml = ` 
<span class="status-cookie green">Status</span>
<span class="status-cookie red">Status</span>
<span class="status-cookie orange">Status</span>
<span class="status-cookie grey">Status</span>
<span class="status-cookie black">Status</span>`

floatButton = `
***No Footer 
<button mat-fab class="float-btn no-footer">
   <mat-icon class="white">add</mat-icon>
 </button>
***With Footer 
<button mat-fab class="float-btn">
   <mat-icon class="white">add</mat-icon>
 </button>
***Secondary Button
<button mat-fab class="float-btn secondary">
   <mat-icon class="white">add</mat-icon>
 </button>`

bannerHTML = `
<div class="information-banner green">
  <mat-icon class="icon">error_outline</mat-icon>
  <div>
    <b>Booking Cancelled</b>
    <div>
      because the owner has a better offer.
    </div>
  </div>
</div>

<div class="information-banner red">
  <mat-icon class="icon">error_outline</mat-icon>
  <div>
    <b>Booking Cancelled</b>
    <div>
      because the owner has a better offer.
    </div>
  </div>
</div>

<div class="information-banner orange">
  <mat-icon class="icon">error_outline</mat-icon>
  <div>
    <b>Booking Cancelled</b>
    <div>
      because the owner has a better offer.
    </div>
  </div>
</div>

<div class="information-banner grey">
  <mat-icon class="icon">error_outline</mat-icon>
  <div>
    <b>Booking Cancelled</b>
    <div>
      because the owner has a better offer.
    </div>
  </div>
</div>

<div class="information-banner black">
  <mat-icon class="icon">error_outline</mat-icon>
  <div>
    <b>Booking Cancelled</b>
    <div>
      because the owner has a better offer.
    </div>
  </div>
</div>`
  constructor(private _snackBar: MatSnackBar, private view: ViewContainerRef, public sharedService: SharedService, private snackBarService: SnackBarService, private dialog: MatDialog
    , public headerService: HeaderService) {
    headerService.header = null;
  }


  ngAfterViewInit() {

  }

  searchBack(){
    window.history.back();
  }

  initSearchProject() {
    (<any>$('.search-project')).toggle(250);
  }

  closeSearchProject() {
    this.value = '';
    (<any>$('.search-project')).toggle(250);
  }


  openSB() {
    this.snackBarService.show("haha", "Undo").subscribe(() => {
    });
  }

  // openDialog() {
  //   const dialogRef = this.dialog.open(ConfirmationDialog, {
  //     width: '320px',
  //     data: { showTextBox: false, title: "Update Confirmation", content: "Choose the update status of the opportunity", yes: "Win", no: "Lose" }
  //   });

  //   dialogRef.afterClosed().subscribe(result => {
  //     if (result) {

  //       result = '';
  //     }
  //     else {

  //     }
  //   });
  // }

  openDialog() {
    const dialogRef = this.dialog.open(PopupImg, {
      width: '320px',
      panelClass: 'custom-dialog-container'
    });
  }

  

  copyToClipboard(text) {
    var dummy = document.createElement("textarea");
    console.log(text)
    document.body.appendChild(dummy);
    if(text == 'searchHtml'){
      dummy.value = this.searchHtml
    }else if(text == 'searchTs') {
      dummy.value = this.searchTs
    }else if(text == 'searchBackTs') {
      dummy.value = this.searchBackTs
    }else if(text == 'searchBackHtml') {
      dummy.value = this.searchBackHtml
    }else if(text == 'component') {
      dummy.value = "ng g c /1/1 --skipTests -is"
    }else{
      dummy.value = "Not Found"
    }
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
    this._snackBar.open("Copied", "", {
      duration: 2000,
    })
  }


}
