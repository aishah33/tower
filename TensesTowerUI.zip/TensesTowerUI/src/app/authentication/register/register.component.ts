import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
  RequiredValidator
} from '@angular/forms';
import { CustomValidators } from 'ng2-validation';
import { MatSnackBar } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

//const password = new FormControl('', Validators.required);
//const confirmPassword = new FormControl('', CustomValidators.equalTo(password));

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  FullName = new FormControl('', [Validators.required, Validators.required]);
  SchoolName = new FormControl('', [Validators.required, Validators.required]);
  UserName = new FormControl('', [Validators.required, Validators.required]);
  Password = new FormControl('', [Validators.required, Validators.required]);

  constructor(private snackBar: MatSnackBar, private http: HttpClient) {}

  OnSubmit() {
    this.FullName.markAsTouched();
    this.SchoolName.markAsTouched();
    this.UserName.markAsTouched();
    this.Password.markAsTouched();

    if(this.FullName.invalid){
      this.FullName.markAsTouched();
      this.snackBar.open('Full Name is required', 'Dimiss!', { duration: 2000 });
      return;
    }

    if(this.SchoolName.invalid){
      this.SchoolName.markAsTouched();
      this.snackBar.open('School Name is required', 'Dismiss', { duration : 2000 });
      return;
    }

    if(this.UserName.invalid){
      this.UserName.markAsTouched();
      this.snackBar.open('User Name is required', 'Dismiss!', { duration: 2000 });
      return;
    }

    if(this.Password.invalid){
      this.Password.markAsTouched();
      this.snackBar.open('Password is required' , 'Dismiss', { duration : 2000 });
      return;
    }

    this.http.post(`${environment.ApiHost}${"/api/Registration/NewStudentRegistration"}`,{
      FullName: this.FullName.value,
      SchoolName: this.SchoolName.value,
      UserName: this.UserName.value,
      Password: this.Password.value
    }).subscribe((data =>{
      console.log(data);
    }), err => console.error(err));

  }

  ngOnInit() {}
}
