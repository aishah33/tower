import { Component, Inject } from "@angular/core";
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from "@angular/material";

@Component({
    selector: 'app-bottom-sheet',
    templateUrl: 'bottom-sheet.html',
})
export class BottomSheet {

    

    constructor(private bottomSheetRef: MatBottomSheetRef<BottomSheet>, @Inject(MAT_BOTTOM_SHEET_DATA) public menuNo: number) {
       
    }

    openLink(event: MouseEvent): void {
        this.bottomSheetRef.dismiss("abc");
        event.preventDefault();
    }
}