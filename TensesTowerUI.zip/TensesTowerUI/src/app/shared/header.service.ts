import { Injectable } from "@angular/core";
import { NavigationExtras, Router } from "@angular/router";

export interface Header {
    title?: string;
    headerIcon?: HeaderIcon;
    headerButton?: HeaderButton[];
    headerStep?: HeaderStep;
}
export interface HeaderIcon {
    icon?: string;
    action?: HeaderAction
}
export interface HeaderAction {
    url?: string;
    parms?: {};
    function?: Function;
}
export interface HeaderButton {
    title?: string
    icon?: string;
    isMenu?: boolean;
    action?: HeaderAction;
}
export interface HeaderStep {
    total: number;
    current?: number;
}

@Injectable()
export class HeaderService {
    public header: Header;
    constructor(private router: Router) { }
    public callBackFunction(action: HeaderAction) {
        if (!action) {
            window.history.back();
            return;
        }
        if (action.function) {
            action.function();
        }
        if (action.url) {
            let navigationExtras: NavigationExtras = {
                queryParams: action.parms || {},
            };

            this.router.navigate([action.url], navigationExtras);
        }
       
    };
    public getButton(): HeaderButton[] {
        if (!this.header.headerButton)
            return [];
        return this.header.headerButton.filter(x => !x.isMenu);
    }
    public getMenu(): HeaderButton[] {
        if (!this.header.headerButton)
            return [];
        return this.header.headerButton.filter(x => x.isMenu);
    }

}