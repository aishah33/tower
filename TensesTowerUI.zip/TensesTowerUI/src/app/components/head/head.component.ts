import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { HeaderService } from '../../shared/header.service';


@Component({
  selector: 'app-head',
  templateUrl: './head.component.html',
  styles: []
})
export class HeadComponent implements OnInit {


  dashboardHeader = `headerService.header = null`
  createHeader = `  
  headerService.header = {
    title: 'New Page',
    headerIcon: {
      icon: 'close'
    },
    headerButton: [
      {
        title: "SAVE",
      }
    ]
  }`
  detailHeader = `  
  headerService.header = {
    title: 'Detail Page'
  }`
  detailWithFunctionHeader = `  
  headerService.header = {
    title: 'Title',
    headerButton: [
      {
        title: "Title",
        icon: 'gavel',
        action: {
          function: () => {
            this.router.navigate(['/index'])
          }
        }
      }
    ]
  }`
  detailWithSearchHeader = `    
  headerService.header = {
    title: 'Title',
    headerButton: [{
      icon: 'search',
      action: {
       function: () => {
         (<any>$('.search-project')).toggle(250);
         
       }
     }
    }]
   }`
  detailWithMenuHeader = `  
  headerService.header = {
    title: 'Detail Page',
    headerButton: [
      {
        isMenu: true,
        title: "Title",
        icon: 'info',
        action: {
          function: () => {
            this.router.navigate(['/index'])
          }
        }
      }
    ]
  }`

  constructor(public headerService: HeaderService, private _snackBar: MatSnackBar) {
    headerService.header = null
  }

  ngOnInit() {
  }

  copyToClipboard(text) {
    var dummy = document.createElement("textarea");
    console.log(text)
    document.body.appendChild(dummy);
    if (text == 'dashboardHeader') {
      dummy.value = this.dashboardHeader
    }else if(text == 'createHeader'){
      dummy.value = this.createHeader
    }else if(text == 'detailHeader'){
      dummy.value = this.detailHeader
    }else if(text == 'detailWithFunctionHeader'){
      dummy.value = this.detailWithFunctionHeader
    }else if(text == 'detailWithSearchHeader'){
      dummy.value = this.detailWithSearchHeader
    } else if(text == 'detailWithMenuHeader'){
      dummy.value = this.detailWithMenuHeader
    }  else {
      dummy.value = "Not Found"
    }
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
    this._snackBar.open("Copied", "", {
      duration: 2000,
    });

  }


}
