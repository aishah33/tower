import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CardComponent } from './card/card.component';
import { ListComponent } from './list/list.component';
import { FormComponent } from './form/form.component';
import { HeadComponent } from './head/head.component';
import { FootComponent } from './foot/foot.component';

const routes: Routes = [
  {
    path: 'card',
    component: CardComponent
  },  {
    path: 'list',
    component: ListComponent
  },  {
    path: 'form',
    component: FormComponent
  },{
    path: 'head',
    component: HeadComponent
  },{
    path: 'foot',
    component: FootComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ComponentsRoutingModule { }
