import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import 'hammerjs';

import { ComponentsRoutingModule } from './components-routing.module';
import { CardComponent } from './card/card.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { DemoMaterialModule } from '../demo-material-module';
import { ListComponent } from './list/list.component';
import { FormComponent } from './form/form.component';
import { HeadComponent } from './head/head.component';
import { FootComponent } from './foot/foot.component';

@NgModule({
  declarations: [CardComponent, ListComponent, FormComponent, HeadComponent, FootComponent],
  imports: [
    CommonModule,
    ComponentsRoutingModule,
    DemoMaterialModule,
    FlexLayoutModule,
  ]
})
export class ComponentsModule { }
