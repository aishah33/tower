import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { HeaderService } from '../../shared/header.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styles: []
})
export class FormComponent implements OnInit {
  userForm = ` 
  <mat-card class="detail-card">
  <div class="form-field">
    <div class="info-container" fxLayout="row wrap">
      <div fxFlex="100">
        <mat-form-field>
          <input matInput required placeholder="Name" value="">
          <mat-error>Field is required</mat-error>
        </mat-form-field>
      </div>
      <div fxFlex="100">
        <mat-form-field>
          <input matInput placeholder="Email" type="email" value="">
          <mat-error>Field is required</mat-error>
        </mat-form-field>
      </div>
      <div fxFlex="100">
        <mat-form-field>
          <input matInput placeholder="Contact" type="phone" value="">
          <mat-error>Field is required</mat-error>
        </mat-form-field>
      </div>
    </div>
  </div>
</mat-card>`

titleForm = `
<mat-card class="detail-card">
<div class="card-title">
  Title
</div>
<div class="card-desc">
  Description
</div>
  <div class="form-field">
    <div class="info-container" fxLayout="row wrap">
      <div fxFlex="100">
        <mat-form-field>
          <input matInput required placeholder="Name" value="">
          <mat-error>Field is required</mat-error>
        </mat-form-field>
      </div>
    </div>
  </div>
</mat-card>`

addressForm = `   
<mat-card class="detail-card">
<div class="card-title">
  Address
</div>
<div class="form-field">
    <div class="info-container" fxLayout="row wrap">
      <div fxFlex="100">
        <mat-form-field>
          <textarea matInput placeholder="Corresspondance Address" row="3" value=""></textarea>
          <mat-error></mat-error>
        </mat-form-field>
      </div>
      <div fxFlex="50" class="left">
        <mat-form-field>
          <input matInput  placeholder="Post Code" type="text" value="">
          <mat-error></mat-error>
        </mat-form-field>
      </div>
      <div fxFlex="50" class="right">
        <mat-form-field>
          <input matInput  placeholder="Country" type="text" value="">
          <mat-error></mat-error>
        </mat-form-field>
      </div>
      <div fxFlex="50" class="left">
          <mat-form-field>
            <input matInput placeholder="State" type="text" value="">
            <mat-error></mat-error>
          </mat-form-field>
        </div>
        <div fxFlex="50" class="right">
          <mat-form-field>
            <input matInput placeholder="City" type="text" value="">
            <mat-error></mat-error>
          </mat-form-field>
        </div>
    </div>
  </div>
</mat-card>`

  constructor(public headerService: HeaderService, private _snackBar: MatSnackBar) {
    headerService.header = null
  }

  ngOnInit() {
  }

  copyToClipboard(text) {
    var dummy = document.createElement("textarea");
    // to avoid breaking orgain page when copying more words
    // cant copy when adding below this code
    // dummy.style.display = 'none'
    console.log(text)
    document.body.appendChild(dummy);
    //Be careful if you use texarea. setAttribute('value', value), which works with "input" does not work with "textarea". – Eduard
    if(text == 'userForm'){
      dummy.value = this.userForm
    }else if(text == 'titleForm'){
      dummy.value = this.titleForm
    }else if(text == 'addressForm'){
      dummy.value = this.addressForm
    }else{
      dummy.value = "Not Found"
    }
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
    this._snackBar.open("Copied", "", {
      duration: 2000,
    });
 
  }

}
