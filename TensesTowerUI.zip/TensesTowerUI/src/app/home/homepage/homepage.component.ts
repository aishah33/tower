import { Component, OnInit } from '@angular/core';
import { HeaderService } from '../../shared/header.service';

@Component({
    selector: 'app-homepage',
    templateUrl: './homepage.component.html'
})
export class HomepageComponent implements OnInit {
    Biodata: any = [];

    constructor(public headerService: HeaderService) {
        headerService.header = null
    }

    ngOnInit() {
    }
}
