import { Component } from '@angular/core';
import { SharedService } from '../../../shared/shared.services';
import { Router } from '@angular/router';
import { HeaderService } from '../../../shared/header.service';

@Component({
  selector: 'app-subheader',
  templateUrl: './subheader.component.html'
})
export class SubheaderComponent {

  constructor(public headerService: HeaderService,private sharedService:SharedService ,private router: Router) {
    this.headerService.header = null;
  }

  toggleSideNav() {
    if (window.innerWidth < 768) {
      this.sharedService.sideNav.toggle();
    }
  }


}
