import { Component, OnInit } from '@angular/core';
import { BottomSheet } from '../../../shared/dialog/bottomSheet/bottom-sheet';
import { MatBottomSheet } from '@angular/material';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html'
})
export class FooterComponent implements OnInit {

  constructor(private bottomSheet:MatBottomSheet) { }

  ngOnInit() {
  }


}
