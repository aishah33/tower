import * as $ from 'jquery';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AppRoutes } from './app.routing';
import { AppComponent } from './app.component';

import { FlexLayoutModule } from '@angular/flex-layout';
import { FullComponent } from './layouts/full/full.component';
import { AppBlankComponent } from './layouts/blank/blank.component';
import { AppHeaderComponent } from './layouts/full/header/header.component';
import { AppSidebarComponent } from './layouts/full/sidebar/sidebar.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DemoMaterialModule } from './demo-material-module';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

import { SharedModule } from './shared/shared.module';
import { SpinnerComponent } from './shared/spinner.component';
import { ConfirmationDialog } from './shared/dialog/confirmation-dialog/confirmation-dialog';
import { BottomSheet } from './shared/dialog/bottomSheet/bottom-sheet';
import { MatBottomSheetRef, MatBottomSheet, MatBottomSheetContainer, MatBottomSheetModule } from '@angular/material';
import { SharedService } from './shared/shared.services';
import { SnackBarService } from './shared/snack.bar.service';
import { SubheaderComponent } from './layouts/full/subheader/subheader.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';

import { NavigationService } from './shared/navigation.service';
import { ChatDialogComponent } from './chat/chat-dialog/chat-dialog.component';
import { ChatModule } from './chat/chat.module';
import { HeaderService } from './shared/header.service';
import { PopupImg } from './shared/dialog/popup-img/popup-img';
import { HomepageComponent } from './home/homepage/homepage.component';
//import { FooterComponent } from './layouts/full/footer/footer.component';



const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true,
  wheelSpeed: 2,
  wheelPropagation: true
};

@NgModule({
  entryComponents: [
    ConfirmationDialog,
    PopupImg,
    BottomSheet,
  ],
  declarations: [
    AppComponent,
    FullComponent,
    AppHeaderComponent,
    SpinnerComponent,
    AppBlankComponent,
    AppSidebarComponent,
    ConfirmationDialog,
    PopupImg,
    BottomSheet,
    SubheaderComponent,
  //  FooterComponent
  
  ],

  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    FormsModule,
    FlexLayoutModule,
    MatBottomSheetModule,
    HttpClientModule,
    PerfectScrollbarModule,
    SharedModule,
    NgMultiSelectDropDownModule.forRoot(),
    RouterModule.forRoot(AppRoutes, { scrollPositionRestoration: 'top' }),
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
  ],

  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG,
    },SharedService,SnackBarService,NavigationService,HeaderService
  ],
 
  bootstrap: [AppComponent]
})
export class AppModule { }
