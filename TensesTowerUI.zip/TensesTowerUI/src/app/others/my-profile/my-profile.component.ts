import { Component, AfterViewInit } from '@angular/core';
import { HeaderService } from '../../../app/shared/header.service';


@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
})
export class MyProfileComponent implements AfterViewInit{


  constructor(public headerService:HeaderService) {
    headerService.header=null
  
  }
     ngAfterViewInit(){
   
  }
 
}

