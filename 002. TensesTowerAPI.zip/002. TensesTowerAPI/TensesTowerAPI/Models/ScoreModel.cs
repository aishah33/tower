﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TensesTowerAPI.Models
{
    public class ScoreModel
    {
        public int RegisterId { get; set; }
        public int Score { get; set; }
    }
}
