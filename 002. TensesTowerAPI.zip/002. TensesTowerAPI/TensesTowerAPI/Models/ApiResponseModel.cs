﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TensesTowerAPI.Business
{
    public class ApiResponseModel
    {
        public bool Status { get; set; }
        public string Message { get; set; }
    }
}
